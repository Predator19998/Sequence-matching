#!/bin/sh
g++ -std=c++11 basic.cpp 
./a.out $1 $2