#!/bin/sh
g++ -std=c++11 efficient.cpp 
./a.out $1 $2